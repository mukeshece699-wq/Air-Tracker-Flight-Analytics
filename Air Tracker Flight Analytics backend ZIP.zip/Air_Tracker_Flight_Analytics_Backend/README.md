# Air Tracker: Flight Analytics
Backend/source-code framework matching the supplied Flight Analytics assignment.

## Included
- AeroDataBox/RapidAPI client with timeout, retries and 429 handling
- 12 selected airports: DEL, BOM, BLR, MAA, HYD, CCU, DXB, SIN, LHR, FRA, JFK, HND
- SQL schema for airport, aircraft, flights and airport_delays
- indexes and the 11 required SQL analytical queries
- Streamlit dashboard: KPIs, flight search/filter, airport viewer, delay chart, read-only SQL explorer
- `.env.example` so the API key is never committed

## API key
Create/access AeroDataBox on RapidAPI, obtain your own key, then copy `.env.example` to `.env` and replace `your_key_here`. Never upload `.env` to GitHub.

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/db.py
python src/collect_airports.py
streamlit run app.py
```

## Important completion note
The project PDF requires live AeroDataBox data for airports, recent flights, unique aircraft and airport delay statistics. The source code can be supplied in GitHub now, but populated tables require your RapidAPI key and API calls under your subscription. Do not commit the API key.

## GitHub submission
Create a repository such as `Air-Tracker-Flight-Analytics`, upload these extracted source files, and submit the repository home URL as Backend Source Code.
