import sqlite3,pandas as pd,streamlit as st,plotly.express as px
st.set_page_config(page_title='Air Tracker: Flight Analytics',layout='wide');st.title('Air Tracker: Flight Analytics')
try:c=sqlite3.connect('flight_analytics.db')
except Exception as e:st.error(e);st.stop()
def scalar(q): return c.execute(q).fetchone()[0]
a,b,d=st.columns(3);a.metric('Airports',scalar('SELECT COUNT(*) FROM airport'));b.metric('Flights',scalar('SELECT COUNT(*) FROM flights'));d.metric('Avg median delay',f"{scalar('SELECT COALESCE(AVG(median_delay_min),0) FROM airport_delays'):.1f} min")
t1,t2,t3,t4=st.tabs(['Flights','Airports','Delay Analysis','SQL Queries'])
with t1:
 q=st.text_input('Flight number / airline');status=st.selectbox('Status',['All']+[x[0] for x in c.execute("SELECT DISTINCT status FROM flights WHERE status IS NOT NULL")]);sql='SELECT * FROM flights WHERE 1=1';p=[]
 if q:sql+=' AND (flight_number LIKE ? OR airline_code LIKE ?)';p += [f'%{q}%',f'%{q}%']
 if status!='All':sql+=' AND status=?';p.append(status)
 st.dataframe(pd.read_sql_query(sql,c,params=p),use_container_width=True)
with t2:
 df=pd.read_sql_query('SELECT * FROM airport ORDER BY name',c);st.dataframe(df,use_container_width=True)
with t3:
 df=pd.read_sql_query('SELECT airport_iata,AVG(median_delay_min) avg_delay,SUM(delayed_flights)*100.0/NULLIF(SUM(total_flights),0) delayed_pct FROM airport_delays GROUP BY airport_iata',c)
 if len(df):st.plotly_chart(px.bar(df,x='airport_iata',y='delayed_pct',hover_data=['avg_delay'],title='Delayed flight percentage by airport'),use_container_width=True)
 else:st.info('Collect airport delay statistics from the AeroDataBox statistical endpoint first.')
with t4:
 st.caption('Required assignment queries are stored in sql/queries.sql');q=st.text_area('Run a read-only SQL query','SELECT * FROM airport LIMIT 20;')
 if st.button('Execute SQL'):
  if not q.lstrip().lower().startswith('select'):st.error('Dashboard allows SELECT queries only.')
  else:
   try:st.dataframe(pd.read_sql_query(q,c),use_container_width=True)
   except Exception as e:st.error(str(e))
