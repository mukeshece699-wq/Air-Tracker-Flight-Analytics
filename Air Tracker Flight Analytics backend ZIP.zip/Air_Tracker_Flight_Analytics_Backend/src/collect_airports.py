from api_client import airport
from db import init_db,connect
CODES=['DEL','BOM','BLR','MAA','HYD','CCU','DXB','SIN','LHR','FRA','JFK','HND']
def val(x,*ks):
 for k in ks:
  if isinstance(x,dict):x=x.get(k)
  else:return None
 return x
init_db();c=connect()
for code in CODES:
 try:
  j=airport(code);loc=j.get('location',{});c.execute('INSERT OR REPLACE INTO airport(airport_id,icao_code,iata_code,name,city,country,continent,latitude,longitude,timezone) VALUES((SELECT airport_id FROM airport WHERE iata_code=?),?,?,?,?,?,?,?,?,?)',(code,j.get('icao'),j.get('iata',code),j.get('name'),val(j,'municipalityName'),val(j,'country','name'),val(j,'continent','name'),loc.get('lat'),loc.get('lon'),j.get('timeZone')));c.commit();print('OK',code)
 except Exception as e:print('ERROR',code,e)
c.close()
