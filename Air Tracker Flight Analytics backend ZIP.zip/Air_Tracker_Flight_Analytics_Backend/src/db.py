import sqlite3
DB='flight_analytics.db'
def connect(): return sqlite3.connect(DB)
def init_db():
 c=connect();c.executescript(open('sql/schema.sql',encoding='utf-8').read());c.close()
if __name__=='__main__':init_db();print('Database initialized')
