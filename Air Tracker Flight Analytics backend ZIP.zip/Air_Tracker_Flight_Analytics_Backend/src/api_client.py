import os,time,requests
from dotenv import load_dotenv
load_dotenv();HOST=os.getenv('RAPIDAPI_HOST','aerodatabox.p.rapidapi.com');KEY=os.getenv('RAPIDAPI_KEY')
def get(path,params=None,retries=3):
 if not KEY: raise RuntimeError('Set RAPIDAPI_KEY in .env')
 u=f'https://{HOST}{path}';h={'x-rapidapi-key':KEY,'x-rapidapi-host':HOST}
 for n in range(retries):
  try:
   r=requests.get(u,headers=h,params=params,timeout=30)
   if r.status_code==429: time.sleep(2**n);continue
   r.raise_for_status();return r.json()
  except requests.RequestException:
   if n==retries-1:raise
   time.sleep(2**n)
def airport(iata): return get(f'/airports/iata/{iata}')
