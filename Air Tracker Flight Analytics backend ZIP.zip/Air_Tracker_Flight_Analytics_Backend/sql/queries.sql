-- 1 Flights per aircraft model
SELECT a.model,COUNT(*) flight_count FROM flights f JOIN aircraft a ON a.registration=f.aircraft_registration GROUP BY a.model ORDER BY flight_count DESC;
-- 2 Aircraft assigned to more than 5 flights
SELECT a.registration,a.model,COUNT(*) flight_count FROM aircraft a JOIN flights f ON f.aircraft_registration=a.registration GROUP BY a.registration,a.model HAVING COUNT(*)>5 ORDER BY flight_count DESC;
-- 3 Airports with more than 5 outbound flights
SELECT a.name,COUNT(*) outbound_flights FROM airport a JOIN flights f ON f.origin_iata=a.iata_code GROUP BY a.iata_code,a.name HAVING COUNT(*)>5 ORDER BY outbound_flights DESC;
-- 4 Top 3 destinations
SELECT a.name,a.city,COUNT(*) arrivals FROM airport a JOIN flights f ON f.destination_iata=a.iata_code GROUP BY a.iata_code,a.name,a.city ORDER BY arrivals DESC LIMIT 3;
-- 5 Domestic/International
SELECT f.flight_number,o.iata_code origin,d.iata_code destination,CASE WHEN o.country=d.country THEN 'Domestic' ELSE 'International' END route_type FROM flights f JOIN airport o ON o.iata_code=f.origin_iata JOIN airport d ON d.iata_code=f.destination_iata;
-- 6 Five most recent arrivals at DEL
SELECT f.flight_number,f.aircraft_registration,o.name departure_airport,COALESCE(f.actual_arrival,f.scheduled_arrival) arrival_time FROM flights f LEFT JOIN airport o ON o.iata_code=f.origin_iata WHERE f.destination_iata='DEL' ORDER BY COALESCE(f.actual_arrival,f.scheduled_arrival) DESC LIMIT 5;
-- 7 Airports with no arrivals
SELECT a.* FROM airport a LEFT JOIN flights f ON f.destination_iata=a.iata_code WHERE f.flight_id IS NULL;
-- 8 Status counts per airline
SELECT airline_code,SUM(CASE WHEN status='On Time' THEN 1 ELSE 0 END) on_time,SUM(CASE WHEN status='Delayed' THEN 1 ELSE 0 END) delayed,SUM(CASE WHEN status='Cancelled' THEN 1 ELSE 0 END) cancelled FROM flights GROUP BY airline_code;
-- 9 Cancelled flights with aircraft and airports
SELECT f.flight_number,a.model,o.name origin,d.name destination,f.scheduled_departure FROM flights f LEFT JOIN aircraft a ON a.registration=f.aircraft_registration LEFT JOIN airport o ON o.iata_code=f.origin_iata LEFT JOIN airport d ON d.iata_code=f.destination_iata WHERE LOWER(f.status)='cancelled' ORDER BY f.scheduled_departure DESC;
-- 10 City pairs with >2 aircraft models
SELECT o.city origin_city,d.city destination_city,COUNT(DISTINCT a.model) aircraft_models FROM flights f JOIN airport o ON o.iata_code=f.origin_iata JOIN airport d ON d.iata_code=f.destination_iata JOIN aircraft a ON a.registration=f.aircraft_registration GROUP BY o.city,d.city HAVING COUNT(DISTINCT a.model)>2 ORDER BY aircraft_models DESC;
-- 11 Delayed arrival percentage
SELECT a.name,COUNT(*) arrivals,ROUND(100.0*SUM(CASE WHEN LOWER(f.status)='delayed' THEN 1 ELSE 0 END)/COUNT(*),2) delayed_pct FROM flights f JOIN airport a ON a.iata_code=f.destination_iata GROUP BY a.iata_code,a.name ORDER BY delayed_pct DESC;
